import pickle
import streamlit as st
import requests
import pandas as pd
import matplotlib.pyplot as plt
from streamlit_option_menu import option_menu
from sklearn.feature_extraction.text import TfidfVectorizer

# Set tiltle cho web
st.set_page_config(page_title='Movie Recommendation',
                   page_icon='🎞',
                   layout = "wide")
with st.sidebar:
    selected = option_menu(menu_title="Main menu",
                               options=['Home','Trending','Review'],
                               icons=['house','graph-up','pencil-square'],
                               menu_icon='cast',
                               default_index=0,
                               
                               )


if selected =='Home':
    movies = pickle.load(open('/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Code/model/movie_list.pkl','rb'))
    similarity = pickle.load(open('/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Code/model/similarity.pkl','rb'))
    def fetch_poster(movie_id):
            url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key=cb6a6e19c5bf52a2031db6eea6e58d8c&language=en-US"
            data = requests.get(url).json()
            poster_path = data.get('poster_path', '')
            full_path = f"https://image.tmdb.org/t/p/original{poster_path}"
            return full_path


        #hàm này lấy tilte của phim thông qua api
    def fetch_title(movie_id):
            url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key=cb6a6e19c5bf52a2031db6eea6e58d8c&language=en-US"
            data = requests.get(url).json()
            title = data.get('title', '')
            return title


        #hàm này lấy overview
    def fetch_overview(movie_id):
            url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key=cb6a6e19c5bf52a2031db6eea6e58d8c&language=en-US"
            data = requests.get(url).json()
            overview = data.get('overview', '')
            return overview



        #hàm này lấy thể loại
    def fetch_genres(movie_id):
            url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key=cb6a6e19c5bf52a2031db6eea6e58d8c&language=en-US"
            data = requests.get(url).json()
            genres = ', '.join([genre['name'] for genre in data.get('genres', [])])
            return genres


        #Hàm này lấy lượng vote trung bình
    def fetch_vote_average(movie_id):
            url = "https://api.themoviedb.org/3/movie/{}?api_key=cb6a6e19c5bf52a2031db6eea6e58d8c&language=en-US".format(movie_id)
            data = requests.get(url)
            data = data.json()
            vote_average = str(data.get('vote_average', ''))
            return vote_average


        #Hàm này lấy thời gian ra bộ phim
    def fetch_release_date(movie_id):
            url = "https://api.themoviedb.org/3/movie/{}?api_key=cb6a6e19c5bf52a2031db6eea6e58d8c&language=en-US".format(movie_id)
            data = requests.get(url)
            data = data.json()
            release_date = data.get('release_date', '')
            return release_date


        #hàm này lấy thời lượng phim
    def fetch_runtime(movie_id):
            url = "https://api.themoviedb.org/3/movie/{}?api_key=cb6a6e19c5bf52a2031db6eea6e58d8c&language=en-US".format(movie_id)
            data = requests.get(url)
            data = data.json()
            runtime = str(data.get('runtime', ''))
            return runtime


        #Hàm này lấy tình trạng phim
    def fetch_status(movie_id):
            url = "https://api.themoviedb.org/3/movie/{}?api_key=cb6a6e19c5bf52a2031db6eea6e58d8c&language=en-US".format(movie_id)
            data = requests.get(url)
            data = data.json()
            status = data.get('status', '')
            return status


        #hàm này lấy vỉdeo trailer của từng bộ phim dựa trên movie_id
    def fetch_movie_trailer(movie_id):
            url = f"https://api.themoviedb.org/3/movie/{movie_id}/videos?api_key=cb6a6e19c5bf52a2031db6eea6e58d8c&language=en-US"
            response = requests.get(url)
            data = response.json()
            trailers = data.get('results', [])
            # Lọc các video trailer
            trailer_urls = [f"https://www.youtube.com/watch?v={trailer['key']}" for trailer in trailers if trailer['site'] == 'YouTube']
            return trailer_urls[:1]  # Chỉ lấy URL của trailer đầu tiên (nếu có)



        #Hàm chức năng chính recommed phim
    def recommend(movie):
            index = movies[movies['movie_title'] == movie].index[0]
            distances = sorted(list(enumerate(similarity[index])), reverse=True, key=lambda x: x[1])
            recommended_movie_names = []
            recommended_movie_posters = []

            for i in distances[1:12]:
                # fetch the movie details
                movie_id = movies.iloc[i[0]].movie_id
                recommended_movie_posters.append(fetch_poster(movie_id))
                recommended_movie_names.append(movies.iloc[i[0]].movie_title)
                # recommended_movie_cast.append(fetch_movie_details(movie_id))

            return recommended_movie_names, recommended_movie_posters

    st.title('Top Movie⭐⭐⭐')
    image_path1 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/The Marvels.jpeg"
    image_path2 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/The avengers.jpeg"
    image_path3 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/Titanic.jpeg"
    image_path4 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/Green Book.jpeg"
    image_path5 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/Ghost Buster.jpeg"
    image_path6 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/Transformer.jpeg"
    image_path7 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/Spider-man.jpeg"
    image_path8 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/Mario.jpeg"
    image_path9 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/Finding nemo.jpeg"
    image_path10 = "/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/Bản sao Ảnh phim/Aladin.jpeg"
        
    
        # container = st.container(height=350, border=None)
        # with container:
    col1, col2, col3, col4, col5, col6, col7,col8 = st.columns(8)
    with col1:
                st.image(image_path2, use_column_width=True, caption='The Avengers')

    with col2:
                st.image(image_path3, use_column_width=True, caption='Titanic')

    with col3:
                st.image(image_path4, use_column_width=True, caption='Green Book')
    with col4:
                st.image(image_path5, use_column_width=True, caption='Ghost Buster')

    with col5:
                st.image(image_path7, use_column_width=True, caption='Spider-man')
    with col6:
                st.image(image_path6, use_column_width=True, caption='Transformer')
    with col7:
                st.image(image_path9, use_column_width=True, caption='Finding nemo')
    with col8:
            st.image(image_path10, use_column_width=True, caption='Aladin')


    st.title('Movie Recommendation System')


        #Chức năng search bằng  selectbox có thể dùng bằng st.input()
    search_query = st.selectbox("Search for a movie by its title", options=movies['movie_title'].tolist(), placeholder="Enter your movie")
        # search_query=st.text_input("Search for a movie by its title",placeholder="Search movie")


    if st.button("Search"):
            if search_query:
                selected_movie = movies[movies['movie_title'].str.contains(search_query, case=False)]
                if not selected_movie.empty:
                    #Đoạn này gán giá trị vào các biến
                    selected_movie = selected_movie.iloc[0]
                    poster_url = fetch_poster(selected_movie['movie_id'])
                    title = fetch_title(selected_movie['movie_id'])
                    overview = fetch_overview(selected_movie['movie_id'])
                    genres = fetch_genres(selected_movie['movie_id'])
                    vote_average=fetch_vote_average(selected_movie['movie_id'])
                    release_date=fetch_release_date(selected_movie['movie_id'])
                    runtime=fetch_runtime(selected_movie['movie_id'])
                    status=fetch_status(selected_movie['movie_id'])
                    trailer=fetch_movie_trailer(selected_movie['movie_id'])

                    # width = 400

                    #Chia ra 2 cột chính col1; dành cho poster phim còn col2 thì cho thông tin của bộ phim như TITLE, OVERVIEW
                    #GENRES,VOTE_AVERAGE, RELEASE_DATE, RUN TIME, STATUS với các câu lệnh như st.write hay st.markdown, st.subheader dùng để chữ to

                    col1, col2 = st.columns(2)
                    with col1:
                        st.image(poster_url, caption=selected_movie['movie_title'], use_column_width=True)

                    with col2:
                        st.subheader(title)
                        st.markdown('Overview:')
                        st.write(overview)
                        st.write('Genres')
                        st.markdown(f"<span style='color:darkgreen'>{genres}</span>", unsafe_allow_html=True)
                        st.write('Vote_average:',vote_average)
                        st.write('Release_date:',release_date)
                        st.write('Run time:',runtime)
                        st.write('Status:',status)


                    # dùng expander để cho phần riêng chạy video trailer
                    expander = st.expander(" ▶️  Play Trailer")
                    if trailer:
                        expander.video(trailer[0])
                    else:
                        expander.write("Trailer not available.")




                    st.divider()
                    #Đoạn này để chạy ra recommend bộ phim dùng vòng lặp for cho chức năng st.columns

                    st.subheader('Recommendation Movie')
                    recommended_movie_names, recommended_movie_posters= recommend(selected_movie['movie_title'])
                    col1,col2,col3,col4 = st.columns(4)
                    with col1:
                            st.write(recommended_movie_names[1])
                            st.image(recommended_movie_posters[1])
                            st.write(recommended_movie_names[5])
                            st.image(recommended_movie_posters[5])

                    with col2:
                            st.write(recommended_movie_names[2])
                            st.image(recommended_movie_posters[2])
                            st.write(recommended_movie_names[6])
                            st.image(recommended_movie_posters[6])
                            st.write(recommended_movie_names[9])
                            st.image(recommended_movie_posters[9])

                    with col3:
                            st.write(recommended_movie_names[3])
                            st.image(recommended_movie_posters[3])
                            st.write(recommended_movie_names[7])
                            st.image(recommended_movie_posters[7])
                            st.write(recommended_movie_names[10])
                            st.image(recommended_movie_posters[10])

                    with col4:
                            st.write(recommended_movie_names[4])
                            st.image(recommended_movie_posters[4])

                            st.write(recommended_movie_names[8])
                            st.image(recommended_movie_posters[8])
   
if selected == 'Trending':
    tab1, tab2 = st.tabs(["Top Rate⭐str", "Plot📊"])
    with tab1:
        import os
        from PIL import Image

        # Đường dẫn đến thư mục lưu trữ ảnh
        image_folder = "/Users/nguyenthiduy/Downloads/image_poster"
        if not os.path.exists(image_folder):
            os.makedirs(image_folder)

        # Load dữ liệu từ các tệp pickle
        movie_score=pickle.load(open('/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Code/model/movie_score.pkl','rb'))
        q_movies = pickle.load(open('/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Code/model/q_movies.pkl', 'rb'))

        # Sắp xếp DataFrame movie_score theo cột 'score' giảm dần và chọn 20 hàng đầu tiên
        top_movies = movie_score.head(30)

        # Tạo tiêu đề cho trang
        st.title('Top Rated Movies⭐⭐⭐')

        # Hiển thị thông tin của từng bộ phim
        for idx in top_movies.index:
            # Lấy thông tin của bộ phim từ DataFrame q_movies
            movie_info = top_movies.loc[idx]
            movie_id = q_movies.loc[idx, 'id']  # Sử dụng cột 'id' thay vì index
            movie_caption=q_movies.loc[idx, 'movie_title']
            movie_released=q_movies.loc[idx,'release_date']
            movie_overview=q_movies.loc[idx,'overview']
            movie_revenue=q_movies.loc[idx,'revenue']

            # Hiển thị tên bộ phim và điểm xếp hạng
            st.subheader(movie_caption)
            st.write(f"Score: {movie_info['score']}")
            st.write("Release Date: ",movie_released)
            st.write("Overview: ",movie_overview)
            st.write('Revenue: ', movie_revenue)

            image_path = os.path.join(image_folder, f"{movie_id}.jpg")

            # Nếu có ảnh cho bộ phim, hiển thị ảnh
            if os.path.exists(image_path):
                image = Image.open(image_path)
                st.image(image, caption=f'{movie_caption}', use_column_width=True)
            else:
                st.write("No image available")
            st.divider()
    with tab2:

        new_data= pickle.load(open('/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Code/model/new_data.pkl', 'rb'))
        # Đảm bảo cột 'popularity' đã được chuyển sang kiểu dữ liệu số (float)
        new_data['popularity'] = new_data['popularity'].astype(float)

        # Sắp xếp DataFrame theo cột 'popularity' giảm dần
        pop = new_data.sort_values('popularity', ascending=False)

        # Tạo biểu đồ
        fig, ax = plt.subplots(figsize=(12, 6))
        ax.barh(pop['title'].head(20), pop['popularity'].head(20), align='center', color='skyblue')
        ax.invert_yaxis()
        ax.set_xlabel("Popularity")
        ax.set_title("Popular Movies")

        # Hiển thị biểu đồ trong Streamlit
        st.title('The Popular Movies ')
        st.pyplot(fig)


        st.title('The Top Rate Plot')
        fig, ax = plt.subplots(figsize=(12, 6))
        # Vẽ biểu đồ đường
        ax.plot(q_movies['movie_title'].head(20), q_movies['score'].head(20), marker='o', color='skyblue', linestyle='-')

        # Đặt nhãn và tiêu đề
        ax.set_xlabel("Movie Title")
        ax.set_ylabel("Score")
        ax.set_title("Popular Movies")

        # Xoay nhãn trục x
        plt.xticks(rotation=45, ha='right')

        # Hiển thị biểu đồ trong Streamlit
        st.pyplot(fig)
if selected == 'Review':
        #Sentiment Analysis   
    st.divider()
    st.title('Predict The Movie Review ')
    model = pickle.load(open('/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Code/model/model.pkl','rb'))
    scaler = pickle.load(open('/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Code/model/scaler.pkl','rb'))
    
    positive_img='/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/meo_cuoi.jpg'
    negative_img='/Users/nguyenthiduy/Downloads/Khái Phá dữ liệu hiệ đại- MovieLEns/Ảnh sentiment/cat_buon.jpg'
    review = st.text_input('Enter Movie Review')

    if st.button('Predict'):
        review_scale = scaler.transform([review]).toarray()
        result = model.predict(review_scale)
        if result[0] == 0:
            st.write('Negative Review')
            st.image(negative_img,use_column_width=True)
            
        else:
            st.write('Positive Review')
            st.image(positive_img,use_column_width=True)
            